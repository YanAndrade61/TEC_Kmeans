import pandas as pd
import numpy as np

def main():
    data = pd.read_csv("s02.txt")
    data = data.to_numpy()
    print("oi",data)